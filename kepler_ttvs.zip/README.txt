TTV data: Column Descriptions

transit_time                center of the transit time [days]
transit duration            duration of the transit [days]
SNR                         signal-to-noise ratio for the transit
successful_optimization     optimization routine for finding the TTV terminated successfully
gap_fraction                fraction of the transit that has missing data
O-C                         transit time - predicted transit time (assuming no TTVs) [min]